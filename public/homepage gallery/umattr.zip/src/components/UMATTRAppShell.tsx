import { Link, Outlet, useLocation } from 'react-router-dom';
import { Home, BookOpen, Compass, Briefcase, Globe, Search, LogIn, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function UMATTRAppShell() {
  const { user, signIn, logOut } = useAuth();
  const location = useLocation();

  const navItems = [
    { path: '/app', icon: Home, label: 'Home' },
    { path: '/academy', icon: BookOpen, label: 'Academy' },
    { path: '/career', icon: Compass, label: 'Career' },
    { path: '/consulting', icon: Briefcase, label: 'Consulting' },
    { path: '/global', icon: Globe, label: 'Global' },
  ];

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#1a1a1a] font-sans selection:bg-[#E6DCC5]">
      <header className="bg-white/80 backdrop-blur-md border-b border-[#E6DCC5] p-4 sticky top-0 z-50 flex justify-between items-center transition-all">
        <h1 className="text-xl font-bold tracking-tight text-gray-900">
          UMA<span className="text-[#C6A55C]">TTR</span>
        </h1>
        <div className="flex items-center gap-4">
          <button className="text-gray-900 hover:text-[#C6A55C] transition-colors">
            <Search size={20} />
          </button>
          {user ? (
            <button onClick={logOut} className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors">
              <LogOut size={18} />
            </button>
          ) : (
            <button onClick={signIn} className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-[#C6A55C] transition-colors">
              <LogIn size={18} />
            </button>
          )}
        </div>
      </header>
      
      <main className="p-4 pb-28 max-w-lg mx-auto">
        <Outlet />
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-lg border-t border-[#E6DCC5] px-2 py-3 flex justify-around items-center z-50 pb-safe">
        {navItems.map((item) => {
          const isActive = location.pathname.startsWith(item.path);
          return (
            <Link 
              key={item.path}
              to={item.path} 
              className={`flex flex-col items-center gap-1 transition-all duration-300 ${isActive ? 'text-[#C6A55C] scale-110' : 'text-gray-400 hover:text-gray-900'}`}
            >
              <item.icon size={22} strokeWidth={isActive ? 2.5 : 2} />
              <span className="text-[10px] font-medium tracking-wide">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
