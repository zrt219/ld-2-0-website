import { useParams, Link } from 'react-router-dom';
import { EXTERNAL_PREVIEWS } from '../data';
import { ArrowLeft, ExternalLink } from 'lucide-react';

export default function ExternalPreviewDetail() {
  const { slug } = useParams();
  const preview = EXTERNAL_PREVIEWS.find(p => p.slug === slug);

  if (!preview) return <div>Preview not found</div>;

  return (
    <div className="animate-in fade-in duration-500 pb-12">
      <Link to="/courses" className="inline-flex items-center text-[#b8860b] mb-4 hover:underline">
        <ArrowLeft size={16} className="mr-1" /> Back to Courses
      </Link>

      <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-[#E6DCC5]">
        <div className="h-48 md:h-64 w-full">
          <img src={preview.heroImage} className="w-full h-full object-cover" alt="" />
        </div>
        <div className="p-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">{preview.title}</h1>
          <p className="text-gray-600 mb-6">{preview.summary}</p>
          
          <a href={preview.externalLink} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center w-full bg-[#b8860b] text-white py-3 rounded-xl font-medium hover:bg-[#9c7209] transition-colors">
            View on UMATTR <ExternalLink size={18} className="ml-2" />
          </a>
        </div>
      </div>
    </div>
  );
}
