import { Link } from 'react-router-dom';
import { PROGRAMS, SAMPLE_COURSE, EXTERNAL_PREVIEWS } from '../data';
import { ExternalLink, Play } from 'lucide-react';

export default function CoursesHub() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {/* Sample Course (In-App) */}
      <section>
        <h2 className="text-lg font-medium text-gray-900 mb-4">Free In-App Sample</h2>
        <Link 
          to={`/courses/samples/${SAMPLE_COURSE.slug}`}
          className="group block bg-white rounded-2xl overflow-hidden shadow-sm border border-[#E6DCC5] hover:border-[#b8860b] transition-all"
        >
          <div className="relative h-48 w-full overflow-hidden">
            <img src={SAMPLE_COURSE.heroImage} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt="" />
            <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
               <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center shadow-lg">
                 <Play className="text-[#b8860b] ml-1" size={24} />
               </div>
            </div>
          </div>
          <div className="p-5">
            <h3 className="font-bold text-lg text-gray-900">{SAMPLE_COURSE.title}</h3>
            <p className="text-sm text-gray-600 mt-2">{SAMPLE_COURSE.summary}</p>
          </div>
        </Link>
      </section>

      {/* Premium Catalog */}
      <section>
        <h2 className="text-lg font-medium text-gray-900 mb-4">Premium Catalog</h2>
        <div className="space-y-4">
          {PROGRAMS.map(program => (
            <Link 
               key={program.slug} 
               to={`/courses/${program.slug}`}
               className="flex bg-white rounded-2xl overflow-hidden shadow-sm border border-[#E6DCC5] hover:border-[#b8860b] transition-colors"
            >
              <div className="w-1/3 min-h-full">
                <img src={program.heroImage} className="w-full h-full object-cover" alt="" />
              </div>
              <div className="p-4 w-2/3">
                <h3 className="font-semibold text-gray-900">{program.title}</h3>
                <p className="text-xs text-gray-500 mt-1 line-clamp-2">{program.summary}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

       {/* External Previews */}
       <section>
        <h2 className="text-lg font-medium text-gray-900 mb-4">More Previews</h2>
        <div className="space-y-3">
          {EXTERNAL_PREVIEWS.map(preview => (
             <Link 
               key={preview.slug} 
               to={`/courses/previews/${preview.slug}`}
               className="flex items-center justify-between bg-white p-4 rounded-xl border border-[#E6DCC5] hover:bg-[#FDFBF7] transition-colors"
             >
                <div className="flex flex-col">
                  <span className="font-medium text-sm text-gray-900">{preview.title}</span>
                  <span className="text-xs text-gray-500">{preview.summary}</span>
                </div>
                <ExternalLink size={18} className="text-[#b8860b]" />
             </Link>
          ))}
        </div>
      </section>

    </div>
  );
}
