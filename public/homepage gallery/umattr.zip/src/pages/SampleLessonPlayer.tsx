import { useParams, Link, useNavigate } from 'react-router-dom';
import { SAMPLE_COURSE } from '../data';
import { ArrowLeft, CheckCircle2, ChevronRight, ChevronLeft } from 'lucide-react';
import { useProgress } from '../hooks/useProgress';
import { useEffect } from 'react';

export default function SampleLessonPlayer() {
  const { courseSlug, lessonSlug } = useParams();
  const navigate = useNavigate();
  const { progress, markCompleted, setCurrentLesson } = useProgress();

  const course = SAMPLE_COURSE; // Hardcoded to single sample for Phase 1
  const lessonIndex = course.lessons.findIndex(l => l.slug === lessonSlug);
  const lesson = course.lessons[lessonIndex];
  
  const prevLesson = lessonIndex > 0 ? course.lessons[lessonIndex - 1] : null;
  const nextLesson = lessonIndex < course.lessons.length - 1 ? course.lessons[lessonIndex + 1] : null;

  useEffect(() => {
    if (lessonSlug) setCurrentLesson(lessonSlug);
    window.scrollTo(0, 0);
  }, [lessonSlug]);

  if (!lesson) return <div>Lesson not found</div>;

  const isCompleted = progress.completedLessons.includes(lesson.slug);

  const handleComplete = () => {
    markCompleted(lesson.slug);
    if (nextLesson) {
      navigate(`/courses/samples/${course.slug}/${nextLesson.slug}`);
    } else {
      navigate(`/courses/${lesson.relatedProgramSlug}`);
    }
  };

  return (
    <div className="animate-in slide-in-from-right-4 duration-300 pb-24">
      <Link to={`/courses/samples/${course.slug}`} className="inline-flex items-center text-gray-500 mb-6 hover:text-[#b8860b] transition-colors">
        <ArrowLeft size={16} className="mr-1" /> Back to Course
      </Link>

      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-3">{lesson.title}</h1>
        <div className="flex items-center gap-3 text-sm text-gray-500">
          <span className="bg-[#FDFBF7] border border-[#E6DCC5] text-[#b8860b] px-2 py-1 rounded-md font-medium">{lesson.durationLabel}</span>
          <span>Part {lessonIndex + 1} of {course.lessons.length}</span>
        </div>
      </div>

      <div className="h-48 md:h-72 w-full rounded-2xl overflow-hidden mb-8 shadow-sm">
        <img src={lesson.heroImage} alt="" className="w-full h-full object-cover" />
      </div>

      <div className="prose prose-stone max-w-none">
        {lesson.sections.map((section, idx) => (
          <div key={idx} className="mb-8">
            <h2 className="text-xl font-bold text-gray-900 mb-3">{section.heading}</h2>
            <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{section.body}</p>
          </div>
        ))}
        
        <div className="bg-[#FDFBF7] p-6 rounded-2xl border border-[#E6DCC5] mb-8">
          <h3 className="font-bold text-gray-900 mb-4 flex items-center">
            <CheckCircle2 size={20} className="text-[#b8860b] mr-2" /> 
            Key Takeaways
          </h3>
          <ul className="space-y-3">
            {lesson.takeaways.map((takeaway, idx) => (
              <li key={idx} className="flex items-start text-gray-700">
                <span className="text-[#b8860b] mr-3 mt-1 font-bold">•</span>
                <span className="leading-tight">{takeaway}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-12 flex flex-col gap-4">
        {isCompleted ? (
          <div className="text-center py-4 bg-[#FDFBF7] border border-[#E6DCC5] rounded-xl text-[#b8860b] font-medium flex items-center justify-center">
            <CheckCircle2 size={20} className="mr-2" /> Completed
          </div>
        ) : (
          <button 
            onClick={handleComplete}
            className="w-full bg-[#b8860b] text-white py-4 rounded-xl font-bold text-lg hover:bg-[#9c7209] transition-colors shadow-sm flex items-center justify-center"
          >
            Mark Complete & Continue
          </button>
        )}

        <div className="flex items-center justify-between mt-6 pt-6 border-t border-[#E6DCC5]">
          {prevLesson ? (
            <Link 
              to={`/courses/samples/${course.slug}/${prevLesson.slug}`}
              className="flex items-center text-gray-600 hover:text-[#b8860b]"
            >
              <ChevronLeft size={20} className="mr-1" />
              <span className="text-sm font-medium">Previous</span>
            </Link>
          ) : <div />}

          {nextLesson ? (
            <Link 
              to={`/courses/samples/${course.slug}/${nextLesson.slug}`}
              className="flex items-center text-gray-600 hover:text-[#b8860b]"
            >
              <span className="text-sm font-medium">Next</span>
              <ChevronRight size={20} className="ml-1" />
            </Link>
          ) : (
            <Link 
              to={`/courses/${lesson.relatedProgramSlug}`}
              className="flex items-center text-[#b8860b] hover:text-[#9c7209]"
            >
              <span className="text-sm font-medium">Full Program</span>
              <ChevronRight size={20} className="ml-1" />
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
