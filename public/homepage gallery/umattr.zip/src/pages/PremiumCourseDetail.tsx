import { useParams, Link } from 'react-router-dom';
import { PROGRAMS, PROGRAMS_URL } from '../data';
import { ArrowLeft, ExternalLink, Twitter, Linkedin, Mail } from 'lucide-react';

export default function PremiumCourseDetail() {
  const { slug } = useParams();
  const program = PROGRAMS.find(p => p.slug === slug);

  if (!program) return <div>Program not found</div>;

  const shareUrl = encodeURIComponent(window.location.href);
  const shareTitle = encodeURIComponent(`Check out ${program.title} on UMATTR`);

  const twitterShareUrl = `https://twitter.com/intent/tweet?url=${shareUrl}&text=${shareTitle}`;
  const linkedinShareUrl = `https://www.linkedin.com/shareArticle?mini=true&url=${shareUrl}&title=${shareTitle}`;
  const emailShareUrl = `mailto:?subject=${shareTitle}&body=${shareUrl}`;

  return (
    <div className="animate-in fade-in duration-500 pb-12">
      <Link to="/courses" className="inline-flex items-center text-[#b8860b] mb-4 hover:underline">
        <ArrowLeft size={16} className="mr-1" /> Back to Courses
      </Link>
      
      <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-[#E6DCC5]">
        <div className="h-48 md:h-64 w-full">
          <img src={program.heroImage} className="w-full h-full object-cover" alt="" />
        </div>
        <div className="p-6">
          <div className="inline-block px-3 py-1 bg-[#FDFBF7] border border-[#E6DCC5] rounded-full text-xs font-medium text-[#b8860b] mb-3">
            Premium Program
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">{program.title}</h1>
          <p className="text-gray-600 mb-6">{program.summary}</p>
          
          <a href={PROGRAMS_URL} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center w-full bg-[#b8860b] text-white py-3 rounded-xl font-medium hover:bg-[#9c7209] transition-colors mb-6">
            Enroll on UMATTR.ca <ExternalLink size={18} className="ml-2" />
          </a>

          <div className="pt-6 border-t border-[#E6DCC5]">
            <h3 className="text-sm font-medium text-gray-900 mb-3">Share this program</h3>
            <div className="flex gap-3">
              <a href={twitterShareUrl} target="_blank" rel="noopener noreferrer" className="p-2 rounded-full bg-[#FDFBF7] border border-[#E6DCC5] text-gray-600 hover:text-[#1DA1F2] hover:border-[#1DA1F2] transition-colors" aria-label="Share on X (Twitter)">
                <Twitter size={20} />
              </a>
              <a href={linkedinShareUrl} target="_blank" rel="noopener noreferrer" className="p-2 rounded-full bg-[#FDFBF7] border border-[#E6DCC5] text-gray-600 hover:text-[#0A66C2] hover:border-[#0A66C2] transition-colors" aria-label="Share on LinkedIn">
                <Linkedin size={20} />
              </a>
              <a href={emailShareUrl} className="p-2 rounded-full bg-[#FDFBF7] border border-[#E6DCC5] text-gray-600 hover:text-[#EA4335] hover:border-[#EA4335] transition-colors" aria-label="Share via Email">
                <Mail size={20} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
