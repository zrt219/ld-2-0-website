import { Link } from 'react-router-dom';
import { SAMPLE_COURSE, PROGRAMS } from '../data';
import { BookOpen, Sparkles, ArrowRight } from 'lucide-react';

export default function Dashboard() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <section className="bg-gradient-to-br from-[#b8860b] to-[#9c7209] p-6 rounded-2xl shadow-sm text-white">
        <h2 className="text-xl font-bold mb-2 tracking-tight">Four Pillars. One Purpose.</h2>
        <p className="text-white/90 text-sm mb-4 leading-relaxed">Built to elevate how the world grows through Products, Academy, Business, and Brands.</p>
        <a href="https://umattr.ca/about" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-sm font-medium border border-white/30 bg-white/10 hover:bg-white/20 transition-colors px-4 py-2 rounded-full">
          Our Story Since 1997
        </a>
      </section>

      <section className="bg-white p-6 rounded-2xl shadow-sm border border-[#E6DCC5]">
        <div className="flex items-center gap-3 mb-4 text-[#b8860b]">
          <Sparkles size={24} />
          <h2 className="text-xl font-medium text-gray-900">Your AI Journey</h2>
        </div>
        <p className="text-gray-600 mb-6">Continue your free trial or explore the premium catalog.</p>
        
        <div className="space-y-4">
          <Link 
            to={`/courses/samples/${SAMPLE_COURSE.slug}`}
            className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-[#FDFBF7] to-white border border-[#E6DCC5] hover:border-[#b8860b] transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg overflow-hidden shrink-0">
                <img src={SAMPLE_COURSE.heroImage} alt="" className="w-full h-full object-cover" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 text-sm">Continue Learning</h3>
                <p className="text-xs text-gray-500">{SAMPLE_COURSE.title}</p>
              </div>
            </div>
            <ArrowRight size={20} className="text-[#b8860b]" />
          </Link>
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium text-gray-900 flex items-center gap-2">
            <BookOpen size={20} className="text-[#b8860b]"/> Premium Programs
          </h2>
          <Link to="/courses" className="text-sm text-[#b8860b] font-medium hover:underline">View All</Link>
        </div>
        <div className="grid gap-4 overflow-x-auto snap-x snap-mandatory flex-nowrap" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))' }}>
          {PROGRAMS.slice(0, 2).map(program => (
            <Link 
               key={program.slug} 
               to={`/courses/${program.slug}`}
               className="block bg-white rounded-2xl overflow-hidden shadow-sm border border-[#E6DCC5] hover:border-[#b8860b] transition-colors snap-start"
            >
              <div className="h-32 w-full">
                <img src={program.heroImage} className="w-full h-full object-cover" alt="" />
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-gray-900">{program.title}</h3>
                <p className="text-sm text-gray-500 mt-1 line-clamp-2">{program.summary}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
