import { Link } from 'react-router-dom';
import { SAMPLE_COURSE } from '../data';
import { ArrowLeft, PlayCircle, CheckCircle2 } from 'lucide-react';
import { useProgress } from '../hooks/useProgress';

export default function SampleCoursePlayer() {
  const { progress } = useProgress();

  return (
    <div className="animate-in fade-in duration-500 pb-12">
      <Link to="/courses" className="inline-flex items-center text-[#b8860b] mb-4 hover:underline">
        <ArrowLeft size={16} className="mr-1" /> Back to Courses
      </Link>

      <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-[#E6DCC5] mb-8">
        <div className="h-48 md:h-64 w-full relative">
          <img src={SAMPLE_COURSE.heroImage} className="w-full h-full object-cover" alt="" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
            <div className="p-6 text-white text-shadow-sm">
                <div className="inline-block px-2 py-1 bg-white/20 backdrop-blur-sm rounded text-xs font-medium mb-2 border border-white/30">
                  Free Sample
                </div>
                <h1 className="text-2xl font-bold mb-1">{SAMPLE_COURSE.title}</h1>
            </div>
          </div>
        </div>
        <div className="p-6 border-b border-[#E6DCC5]">
          <p className="text-gray-600">{SAMPLE_COURSE.summary}</p>
        </div>
        
        <div className="p-0">
          <div className="px-6 py-4 bg-[#FDFBF7] border-b border-[#E6DCC5]">
            <h2 className="text-sm font-semibold text-gray-900 uppercase tracking-wider">Lessons</h2>
          </div>
          <div className="divide-y divide-[#E6DCC5]">
            {SAMPLE_COURSE.lessons.map((lesson, idx) => {
              const isCompleted = progress.completedLessons.includes(lesson.slug);
              
              return (
                <Link 
                  key={lesson.slug}
                  to={`/courses/samples/${SAMPLE_COURSE.slug}/${lesson.slug}`}
                  className="flex items-center p-6 hover:bg-[#FDFBF7] transition-colors"
                >
                  <div className="mr-4">
                    {isCompleted ? (
                      <CheckCircle2 className="text-[#b8860b]" size={28} />
                    ) : (
                      <div className="w-7 h-7 rounded-full border-2 border-[#E6DCC5] flex items-center justify-center text-xs font-bold text-gray-400">
                        {idx + 1}
                      </div>
                    )}
                  </div>
                  <div className="flex-1 pr-4">
                    <h3 className={`font-medium ${isCompleted ? 'text-gray-900' : 'text-gray-900'}`}>
                      {lesson.title}
                    </h3>
                    <p className="text-xs text-gray-500 mt-1">{lesson.durationLabel} • {lesson.summary}</p>
                  </div>
                  <PlayCircle className="text-[#E6DCC5] shrink-0" size={24} />
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
