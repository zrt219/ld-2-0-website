export interface Program {
  slug: string;
  title: string;
  heroImage: string;
  summary: string;
  isPremium: boolean;
}

export interface ExternalPreview {
  slug: string;
  title: string;
  heroImage: string;
  summary: string;
  externalLink: string;
}

export interface SampleLesson {
  slug: string;
  title: string;
  durationLabel: string;
  heroImage: string;
  summary: string;
  sections: { heading: string; body: string }[];
  takeaways: string[];
  nextLessonSlug?: string;
  relatedProgramSlug: string;
}

export interface SampleCourse {
  slug: string;
  title: string;
  heroImage: string;
  summary: string;
  lessons: SampleLesson[];
}

export interface SampleProgressState {
  completedLessons: string[];
  currentLessonSlug: string;
}
