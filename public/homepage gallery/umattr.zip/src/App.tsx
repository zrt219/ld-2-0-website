/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Download, FolderArchive, Smartphone } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-[#FDFBF7] flex items-center justify-center p-6 text-[#1A1A1A] font-sans">
      <div className="max-w-2xl w-full bg-white rounded-2xl p-10 md:p-16 shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-gray-100/50 text-center">
        <div className="w-20 h-20 bg-[#FDFBF7] rounded-full flex items-center justify-center mx-auto mb-8">
          <Smartphone className="w-10 h-10 text-[#C6A55C]" />
        </div>
        
        <h1 className="text-3xl md:text-4xl font-medium tracking-tight mb-4">
          UMATTR Android Project Ready
        </h1>
        
        <p className="text-lg text-gray-600 mb-10 max-w-lg mx-auto leading-relaxed">
          The complete native Android Kotlin and Jetpack Compose project for UMATTR has been successfully generated.
        </p>

        <div className="bg-gray-50 rounded-xl p-6 mb-10 text-left border border-gray-100 flex flex-col sm:flex-row gap-6 items-start">
           <FolderArchive className="w-8 h-8 text-gray-400 shrink-0" />
           <div>
             <h3 className="font-medium text-gray-900 mb-2">How to access your app</h3>
             <ul className="text-sm text-gray-600 space-y-2">
               <li>1. Open the File Explorer in the AI Studio editor.</li>
               <li>2. Locate the <strong><code>android</code></strong> directory containing the full Gradle project.</li>
               <li>3. Use the Export or Download feature to save the project as a ZIP file.</li>
               <li>4. Open the extracted folder in <strong>Android Studio</strong>.</li>
             </ul>
           </div>
        </div>

        <p className="text-sm text-gray-500">
          Built with Material 3, Jetpack Compose Navigation, and Clean Architecture patterns.
        </p>
      </div>
    </div>
  );
}
