import { useState, useEffect } from 'react';
import { SampleProgressState } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { fetchUserProgress, saveUserProgress } from '../lib/firebase';

const PROGRESS_KEY = 'umattr:sample-progress:v1';

export function useProgress() {
  const { user } = useAuth();
  const [progress, setProgress] = useState<SampleProgressState>(() => {
    const saved = localStorage.getItem(PROGRESS_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse progress', e);
      }
    }
    return { completedLessons: [], currentLessonSlug: '' };
  });

  // Listen for user login/logout and fetch from FB
  useEffect(() => {
    async function initFirebaseProgress() {
      if (user) {
        const fbProgress = await fetchUserProgress(user.uid);
        if (fbProgress) {
          // Merge remote with local. If remote is present, we use remote. 
          // If local has more data, we could merge, but overwriting with remote is safer for phase 1.
          setProgress(fbProgress);
        } else {
          // No user data yet in FB, save current local progress
          await saveUserProgress(user.uid, progress);
        }
      }
    }
    initFirebaseProgress();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // Sync to local storage & Firebase when changed
  useEffect(() => {
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
    if (user) {
      // Sync to FB. In a real app we'd debounce this.
      saveUserProgress(user.uid, progress).catch(err => {
        console.error('Failed to save to firebase', err);
      });
    }
  }, [progress, user]);

  const markCompleted = (lessonSlug: string) => {
    setProgress(prev => {
      if (prev.completedLessons.includes(lessonSlug)) return prev;
      return {
        ...prev,
        completedLessons: [...prev.completedLessons, lessonSlug]
      };
    });
  };

  const setCurrentLesson = (lessonSlug: string) => {
    setProgress(prev => {
      if (prev.currentLessonSlug === lessonSlug) return prev;
      return { ...prev, currentLessonSlug: lessonSlug };
    });
  };

  return { progress, markCompleted, setCurrentLesson };
}
