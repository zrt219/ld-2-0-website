import { Program, SampleCourse, ExternalPreview } from './types';

export const PROGRAMS_URL = "https://umattr.ca/courses";

export const PROGRAMS: Program[] = [
  { slug: 'ai-foundations', title: 'UMATTR AI Foundations', heroImage: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=2565&auto=format&fit=crop', summary: 'Master the basics of AI in this premium foundation program.', isPremium: true },
  { slug: 'ai-for-work', title: 'UMATTR AI for Work', heroImage: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?q=80&w=2670&auto=format&fit=crop', summary: 'Integrate AI into your daily professional workflow to build real skills.', isPremium: true },
  { slug: 'ai-for-business', title: 'UMATTR AI for Business', heroImage: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2670&auto=format&fit=crop', summary: 'Strategic AI implementation and intelligence for enterprise and organizational growth.', isPremium: true },
];

export const EXTERNAL_PREVIEWS: ExternalPreview[] = [
  { slug: 'ai-landscape', title: 'The AI Landscape Today', heroImage: 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?q=80&w=2670&auto=format&fit=crop', summary: 'A free preview lesson hosted on Payhip.', externalLink: 'https://umattr.ca/preview/landscape' },
];

export const SAMPLE_COURSE: SampleCourse = {
  slug: 'ai-foundations-sample',
  title: 'AI Foundations: Free Sample',
  heroImage: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=2565&auto=format&fit=crop',
  summary: 'Experience 3 mini-lessons from our premium AI Foundations program.',
  lessons: [
    {
      slug: 'what-ai-is',
      title: 'What is AI, Really?',
      durationLabel: '5 min',
      heroImage: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?q=80&w=2670&auto=format&fit=crop',
      summary: 'Cut through the jargon and understand what large language models actually do.',
      sections: [
        { heading: 'The Core Concept', body: 'AI, specifically generative AI, is basically advanced pattern recognition. It predicts the most likely next word based on massive amounts of reading material.' },
        { heading: 'Why It Matters', body: 'Understanding this helps you avoid treating AI like an oracle or a search engine. It is a reasoning engine.'}
      ],
      takeaways: ['AI is pattern recognition', 'It predicts the next word', 'Treat it as a reasoning engine, not a database'],
      nextLessonSlug: 'better-questions',
      relatedProgramSlug: 'ai-foundations',
    },
    {
      slug: 'better-questions',
      title: 'Asking Better Questions',
      durationLabel: '7 min',
      heroImage: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?q=80&w=2670&auto=format&fit=crop',
      summary: 'Learn the foundational techniques for creating effective prompts.',
      sections: [
        { heading: 'Context is King', body: 'The more context you give an AI, the better the answer. Tell it who it is, what the goal is, and who the audience is.' },
        { heading: 'Iterative Refinement', body: 'Your first prompt will rarely be perfect. Engage in a dialogue to refine the output.'}
      ],
      takeaways: ['Provide rich context', 'Define roles and goals', 'Iterate through conversation'],
      nextLessonSlug: 'safer-ai-use',
      relatedProgramSlug: 'ai-foundations',
    },
    {
      slug: 'safer-ai-use',
      title: 'Safe and Ethical AI Use',
      durationLabel: '6 min',
      heroImage: 'https://images.unsplash.com/photo-1563206767-5b18f218e8de?q=80&w=2669&auto=format&fit=crop',
      summary: 'Understand the risks of hallucinations and data privacy.',
      sections: [
        { heading: 'Hallucinations', body: 'AI can confidently make things up. Always verify factual claims, especially for important decisions.' },
        { heading: 'Data Privacy', body: 'Do not put sensitive personal or corporate data into public consumer AI tools without checking the privacy policy.'}
      ],
      takeaways: ['Always fact-check AI outputs', 'Protect sensitive data', 'Understand the limitations of the tools'],
      relatedProgramSlug: 'ai-foundations',
    },
  ],
};
