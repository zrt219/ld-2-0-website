# Security Spec

## 1. Data Invariants
- A user's progress record can only be accessed and updated by the user themselves (`userId == request.auth.uid`).
- `completedLessons` must be an array of strings, max 100 items.
- `currentLessonSlug` must be a string, max 100 characters.
- `updatedAt` must be updated to the server timestamp on every write.

## 2. The "Dirty Dozen" Payloads
1. **Identity Spoofing**: Attempt to read/write `/users/fake-id/progress/sample` as a user with UID `real-id`. (Expected: DENIED)
2. **Missing required field**: Save `completedLessons` without `updatedAt`. (Expected: DENIED)
3. **Ghost Field**: Send `completedLessons`, `updatedAt`, and `isAdmin: true`. (Expected: DENIED)
4. **Invalid Type**: Send `completedLessons: "not-an-array"`. (Expected: DENIED)
5. **Array Element Invalid Type**: Send `completedLessons: [1, 2, 3]` (numbers instead of strings). (Expected: DENIED)
6. **Denial of Wallet (Large Array)**: Send 10,000 items in `completedLessons`. (Expected: DENIED, max 100)
7. **Denial of Wallet (Large String)**: Send a `currentLessonSlug` that is 50,000 characters long. (Expected: DENIED, max 128)
8. **Invalid Timestamp**: Client sends `updatedAt: "2023-01-01"` instead of `request.time`. (Expected: DENIED)
9. **Update missing updatedAt**: Update `completedLessons` but don't change/update `updatedAt` to `request.time`. (Expected: DENIED)
10. **Unauthenticated Read/Write**: Attempt operation without being signed in. (Expected: DENIED)
11. **Path Variable ID Poisoning**: Using a `userId` containing malicious characters. (Expected: DENIED)
12. **Blanket Read**: Attempting to read `/users` or querying across user boundaries without `userId == request.auth.uid`. (Expected: DENIED)

## 3. The Test Runner
A `firestore.rules.test.ts` file will be required to run these payloads and confirm they return `PERMISSION_DENIED`, using `@firebase/rules-unit-testing`.
