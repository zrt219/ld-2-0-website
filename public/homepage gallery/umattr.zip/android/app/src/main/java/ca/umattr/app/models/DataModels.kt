package ca.umattr.app.models

data class Program(
    val id: String,
    val title: String,
    val description: String,
    val bestFor: String,
    val accessState: AccessState,
    val detailViews: List<String> = emptyList()
)

enum class AccessState {
    FREE_PREVIEW, PAID, COMING_SOON, EXTERNAL_CHECKOUT
}

data class Region(
    val id: String,
    val name: String,
    val readinessTheme: String,
    val peopleText: String,
    val workforceText: String,
    val aiEducationText: String,
    val futureSystemsText: String,
    val isFlagship: Boolean = false
)

data class ConsultingPackage(
    val id: String,
    val name: String,
    val features: List<String>,
    val priceLabel: String
)

data class RouteFinderQuestion(
    val id: String,
    val prompt: String,
    val options: List<String>
)

data class RouteFinderResult(
    val recommendedRoute: String,
    val nextStepAction: String
)

data class ReadinessMetric(
    val label: String,
    val score: Int
)

data class ProductCard(
    val title: String,
    val subtitle: String,
    val isAvailable: Boolean
)

data class FAQItem(
    val question: String,
    val answer: String
)
