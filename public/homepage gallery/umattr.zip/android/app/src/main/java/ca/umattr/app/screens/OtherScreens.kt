package ca.umattr.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import ca.umattr.app.ui.theme.DeepBlack
import ca.umattr.app.ui.theme.Ivory

@Composable
fun GlobalScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ivory)
            .padding(24.dp)
    ) {
        Text("Global Readiness", style = MaterialTheme.typography.headlineLarge, color = DeepBlack)
        // Render regions here
    }
}

@Composable
fun MoreScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ivory)
            .padding(24.dp)
    ) {
        Text("More", style = MaterialTheme.typography.headlineLarge, color = DeepBlack)
        // Settings, FAQ, Contact
    }
}

@Composable
fun RouteFinderScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ivory)
            .padding(24.dp)
    ) {
        Text("Route Finder", style = MaterialTheme.typography.headlineLarge, color = DeepBlack)
    }
}

@Composable
fun ProgramDetailScreen(navController: NavController, programId: String?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ivory)
            .padding(24.dp)
    ) {
        Text("Program Detail", style = MaterialTheme.typography.headlineLarge, color = DeepBlack)
    }
}

@Composable
fun ConsultingIntakeScreen(navController: NavController) {
    Column(modifier = Modifier.fillMaxSize().background(Ivory).padding(24.dp)) {
        Text("Intake", style = MaterialTheme.typography.headlineLarge, color = DeepBlack)
    }
}

@Composable
fun RegionDetailScreen(navController: NavController, regionId: String?) {
    Column(modifier = Modifier.fillMaxSize().background(Ivory).padding(24.dp)) {
        Text("Region Detail", style = MaterialTheme.typography.headlineLarge, color = DeepBlack)
    }
}

@Composable
fun ProductsScreen(navController: NavController) {}
@Composable
fun GameStudiosScreen(navController: NavController) {}
@Composable
fun FAQScreen(navController: NavController) {}
@Composable
fun SettingsScreen(navController: NavController) {}
