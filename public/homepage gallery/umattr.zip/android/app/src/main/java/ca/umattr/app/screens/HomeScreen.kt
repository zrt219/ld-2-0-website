package ca.umattr.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import ca.umattr.app.ui.theme.*

@Composable
fun HomeScreen(navController: NavController) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ivory)
            .verticalScroll(scrollState)
            .padding(24.dp)
    ) {
        // Top Bar Area
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "UMATTR",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = ChampagneGold)
            )
            IconButton(onClick = { /* Open command search */ }) {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = DeepBlack)
            }
        }

        Spacer(modifier = Modifier.height(48.dp))

        // Hero Section
        Text(
            text = "AI learning that builds real skills and shapes your future.",
            style = MaterialTheme.typography.headlineLarge,
            color = DeepBlack
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Practical AI learning, career intelligence, and consulting.",
            style = MaterialTheme.typography.bodyLarge,
            color = GrayText
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Primary CTAs
        Button(
            onClick = { navController.navigate("routeFinder") },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DeepBlack, contentColor = SoftWhite),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Find Your Route", style = MaterialTheme.typography.labelLarge)
        }
        
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = { navController.navigate("academy") },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = DeepBlack),
            border = androidx.compose.foundation.BorderStroke(1.dp, SubtleBorder),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Explore Programs", style = MaterialTheme.typography.labelLarge)
        }

        Spacer(modifier = Modifier.height(48.dp))

        // Cards Section
        SectionTitle("Focus Areas")
        Spacer(modifier = Modifier.height(16.dp))
        
        HomeCard("Practical AI Skills", "Learn the fundamentals and apply them.", onClick = { navController.navigate("academy") })
        HomeCard("Career Direction", "Navigate your industry pivot.", onClick = { navController.navigate("career") })
        HomeCard("Business Support", "Integrate AI securely into operations.", onClick = { navController.navigate("consulting") })
        HomeCard("Global AI Readiness", "Understanding the worldwide AI landscape.", onClick = { navController.navigate("global") })
        
        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        color = DeepBlack
    )
}

@Composable
fun HomeCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = SoftWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SubtleBorder)
    ) {
        Row(
            modifier = Modifier.padding(20.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.titleLarge, color = DeepBlack)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = subtitle, style = MaterialTheme.typography.bodyMedium, color = GrayText)
            }
            Icon(Icons.Default.ArrowForward, contentDescription = "Go", tint = ChampagneGold)
        }
    }
}
