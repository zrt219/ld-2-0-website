package ca.umattr.app.ui.theme

import androidx.compose.ui.graphics.Color

val Ivory = Color(0xFFFDFBF7)
val DeepBlack = Color(0xFF1A1A1A)
val ChampagneGold = Color(0xFFC6A55C)
val SoftWhite = Color(0xFFFFFFFF)
val SubtleBorder = Color(0xFFE5E5E5)
val LightGold = Color(0xFFE8D5A5)
val GrayText = Color(0xFF666666)
val ErrorRed = Color(0xFFB00020)
