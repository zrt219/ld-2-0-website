package ca.umattr.app.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Work
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavController
import ca.umattr.app.ui.theme.ChampagneGold
import ca.umattr.app.ui.theme.DeepBlack
import ca.umattr.app.ui.theme.Ivory

data class NavItem(val route: String, val title: String, val icon: ImageVector)

@Composable
fun BottomNavigationBar(navController: NavController, currentRoute: String?) {
    val items = listOf(
        NavItem("home", "Home", Icons.Default.Home),
        NavItem("academy", "Academy", Icons.Default.School),
        NavItem("career", "Career", Icons.Default.Work),
        NavItem("consulting", "Consulting", Icons.Default.Handshake),
        NavItem("global", "Global", Icons.Default.Public),
        NavItem("more", "More", Icons.Default.Menu)
    )

    NavigationBar(
        containerColor = Ivory,
        contentColor = DeepBlack
    ) {
        items.forEach { item ->
            NavigationBarItem(
                icon = { Icon(item.icon, contentDescription = item.title) },
                label = { Text(item.title) },
                selected = currentRoute == item.route,
                onClick = {
                    navController.navigate(item.route) {
                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Ivory,
                    selectedTextColor = DeepBlack,
                    indicatorColor = ChampagneGold,
                    unselectedIconColor = DeepBlack.copy(alpha = 0.6f),
                    unselectedTextColor = DeepBlack.copy(alpha = 0.6f)
                )
            )
        }
    }
}
