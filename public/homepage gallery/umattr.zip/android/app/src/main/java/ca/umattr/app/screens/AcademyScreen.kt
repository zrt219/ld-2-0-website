package ca.umattr.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import ca.umattr.app.models.AccessState
import ca.umattr.app.models.Program
import ca.umattr.app.ui.theme.*

@Composable
fun AcademyScreen(navController: NavController) {
    val programs = listOf(
        Program("1", "UMATTR AI Foundations", "The essential starting point for practical AI use.", "Individuals", AccessState.FREE_PREVIEW),
        Program("2", "UMATTR AI for Work", "Apply AI to everyday knowledge work and operations.", "Professionals", AccessState.PAID),
        Program("3", "UMATTR AI for Business", "Strategic integration for leadership and teams.", "Teams", AccessState.PAID)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ivory)
            .padding(top = 24.dp, start = 24.dp, end = 24.dp)
    ) {
        Text(
            text = "Academy",
            style = MaterialTheme.typography.headlineLarge,
            color = DeepBlack
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Master practical AI skills for your future.",
            style = MaterialTheme.typography.bodyLarge,
            color = GrayText
        )
        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn(
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(programs) { program ->
                ProgramCard(program) {
                    navController.navigate("programDetail/${program.id}")
                }
            }
        }
    }
}

@Composable
fun ProgramCard(program: Program, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SoftWhite),
        border = androidx.compose.foundation.BorderStroke(1.dp, SubtleBorder),
        onClick = onClick
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Surface(
                color = LightGold,
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Text(
                    text = "BEST FOR: ${program.bestFor.uppercase()}",
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = DeepBlack
                )
            }
            
            Text(text = program.title, style = MaterialTheme.typography.titleLarge, color = DeepBlack)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = program.description, style = MaterialTheme.typography.bodyMedium, color = GrayText)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            val accessText = when (program.accessState) {
                AccessState.FREE_PREVIEW -> "Start Free Preview"
                AccessState.PAID -> "Enroll Now"
                AccessState.EXTERNAL_CHECKOUT -> "Opens Checkout"
                AccessState.COMING_SOON -> "Coming Soon"
            }
            
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = DeepBlack, contentColor = SoftWhite),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(accessText)
            }
        }
    }
}
