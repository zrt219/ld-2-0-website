package ca.umattr.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import ca.umattr.app.ui.theme.*

@Composable
fun ConsultingScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ivory)
            .padding(24.dp)
    ) {
        Text("Consulting", style = MaterialTheme.typography.headlineLarge, color = DeepBlack)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Systems, operations, and risk management.", style = MaterialTheme.typography.bodyLarge, color = GrayText)
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Button(
            onClick = { navController.navigate("consultingIntake") },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DeepBlack, contentColor = SoftWhite),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Start Project Intake")
        }
    }
}
