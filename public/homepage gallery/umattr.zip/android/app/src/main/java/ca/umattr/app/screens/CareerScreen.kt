package ca.umattr.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import ca.umattr.app.ui.theme.*

@Composable
fun CareerScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ivory)
            .padding(24.dp)
    ) {
        Text("Career Intelligence", style = MaterialTheme.typography.headlineLarge, color = DeepBlack)
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DeepBlack),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    "Navigate your AI pivot.",
                    style = MaterialTheme.typography.titleLarge,
                    color = SoftWhite
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Role clarity, positioning, and strategic decisions for a changing job market.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = SoftWhite.copy(alpha = 0.8f)
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { /* Access CI */ },
                    colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold, contentColor = DeepBlack),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Access Intelligence", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
