package ca.umattr.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ca.umattr.app.components.BottomNavigationBar
import ca.umattr.app.screens.*

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    val navBackStackEntry = navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry.value?.destination?.route

    Scaffold(
        bottomBar = {
            if (currentRoute in listOf("home", "academy", "career", "consulting", "global", "more")) {
                BottomNavigationBar(navController = navController, currentRoute = currentRoute)
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") { HomeScreen(navController) }
            composable("academy") { AcademyScreen(navController) }
            composable("career") { CareerScreen(navController) }
            composable("consulting") { ConsultingScreen(navController) }
            composable("global") { GlobalScreen(navController) }
            composable("more") { MoreScreen(navController) }
            
            composable("routeFinder") { RouteFinderScreen(navController) }
            composable("programDetail/{programId}") { backStackEntry ->
                val id = backStackEntry.arguments?.getString("programId")
                ProgramDetailScreen(navController, id)
            }
            composable("consultingIntake") { ConsultingIntakeScreen(navController) }
            composable("regionDetail/{regionId}") { backStackEntry ->
                 val id = backStackEntry.arguments?.getString("regionId")
                 RegionDetailScreen(navController, id)
            }
            composable("products") { ProductsScreen(navController) }
            composable("gameStudios") { GameStudiosScreen(navController) }
            composable("faq") { FAQScreen(navController) }
            composable("settings") { SettingsScreen(navController) }
        }
    }
}
